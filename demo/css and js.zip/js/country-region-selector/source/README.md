## Country-Region-Selector - source

The data source for this repo has been moved here: 
https://github.com/benkeen/country-region-data
